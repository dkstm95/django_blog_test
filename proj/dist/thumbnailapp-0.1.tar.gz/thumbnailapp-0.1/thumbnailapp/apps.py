from django.apps import AppConfig


class ThumbnailappConfig(AppConfig):
    name = 'thumbnailapp'
